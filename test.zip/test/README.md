# lem-in_test

![Illustration](http://i.imgur.com/SQbZrk7.png)  
Lots of tests for lem-in @ 42.  

###What  
>This shell script will take your lem-in executable and perform a lot of tests (More than 100) to test errors and correct paths for lem-in.  
>Maybe all the tests are not here, and maybe your program will not react as expected for this test. This is not always errors, it just can be your own way for this project.  
>Please note that this script doesn't do the correction for you, and you have to test the program by yourself !  
>Please, do not hesitate to report issues !  

###How to :  
1. git clone https://bitbucket.org/Tbouder/lem-in_test  
2. sh unit_tests.sh  
3. Enter the path to the directory containing your lem-in  
4. Press enter  
